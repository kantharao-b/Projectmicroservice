package com.plan.service;

import com.plan.DTO.CustomerDTO;
import com.plan.DTO.LoginDTO;
import com.plan.DTO.RegisterDTO;

public interface CustomerService {
boolean registerCustomer(RegisterDTO registerDTO);
boolean loginCustomer(LoginDTO loginDTO);
CustomerDTO readCustomer(Long phoneNumber);

}
