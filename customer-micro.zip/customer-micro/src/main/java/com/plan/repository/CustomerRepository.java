package com.plan.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.customer.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Serializable> {

	@Query(value="select count(*) from customer where phoneNumber=? and password=?",nativeQuery=true)
	Integer loginCheck(Long phoneNumber,String password);
}
