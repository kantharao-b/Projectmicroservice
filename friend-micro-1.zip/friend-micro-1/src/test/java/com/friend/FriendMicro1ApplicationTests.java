package com.friend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FriendMicro1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
