package com.friend.service;

import java.util.List;

import com.friend.entity.Friend;

public interface FriendService {
 String addFriend(Friend friend);
 List<Long> readFriendContacts(Long phoneNumber);
}
