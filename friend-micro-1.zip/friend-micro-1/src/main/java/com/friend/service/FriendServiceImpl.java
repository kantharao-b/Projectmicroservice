package com.friend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.friend.entity.Friend;
import com.friend.repository.FriendRepository;
@Service
public class FriendServiceImpl implements FriendService{
@Autowired
private FriendRepository repository;
	@Override
	public String addFriend(Friend friend) {
		Integer count = repository.checkFriendContact(friend.getFriendNumber(),friend.getPhoneNumber());
		if(count==0) {
			repository.saveAndFlush(friend);
			return "Successfully Inserted";
		}
		return "Already data is available";
	}

	@Override
	public List<Long> readFriendContacts(Long phoneNumber) {
		
		return repository.findFriendsContactNumbers(phoneNumber);
	}

}
