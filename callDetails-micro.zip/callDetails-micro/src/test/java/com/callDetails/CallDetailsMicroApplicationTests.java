package com.callDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CallDetailsMicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
