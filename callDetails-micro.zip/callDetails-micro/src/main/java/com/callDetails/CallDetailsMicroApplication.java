package com.callDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CallDetailsMicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(CallDetailsMicroApplication.class, args);
	}

}
