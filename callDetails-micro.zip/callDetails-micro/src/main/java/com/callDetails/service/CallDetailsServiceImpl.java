package com.callDetails.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.callDetails.DTO.CallDetailsDTO;
import com.callDetails.entity.CallDetails;
import com.callDetails.repository.CallDetailsRepository;
@Service
public class CallDetailsServiceImpl implements CallDetailsService{
	@Autowired
	private CallDetailsRepository repository;
	@Override
	public List<CallDetailsDTO> readAllDetails(Long PhoneNumber) {
		List<CallDetails> callDetailsList = repository.findByCalledBy(PhoneNumber);
		List<CallDetailsDTO> callDetailsDTOList=new ArrayList<CallDetailsDTO>();
		callDetailsList.forEach(dtls->{
			CallDetailsDTO dto=new CallDetailsDTO();
			BeanUtils.copyProperties(dtls, dto);
			callDetailsDTOList.add(dto);	
		});
		return callDetailsDTOList;
	}

}
