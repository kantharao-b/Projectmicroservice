package com.callDetails.service;

import java.util.List;

import com.callDetails.DTO.CallDetailsDTO;

public interface CallDetailsService {

	List<CallDetailsDTO> readAllDetails(Long PhoneNumber);
	
}
