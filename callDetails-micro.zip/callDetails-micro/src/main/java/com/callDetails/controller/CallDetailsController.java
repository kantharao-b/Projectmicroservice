package com.callDetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.callDetails.DTO.CallDetailsDTO;
import com.callDetails.service.CallDetailsService;
@RestController
public class CallDetailsController {

	@Autowired
	private CallDetailsService service;
	@GetMapping("/{PhoneNumber}")
	public List<CallDetailsDTO> findAll(@PathVariable Long PhoneNumber){
		return service.readAllDetails(PhoneNumber);
	}
}
