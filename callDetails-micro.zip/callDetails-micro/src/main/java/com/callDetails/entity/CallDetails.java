package com.callDetails.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="CALL_DETAILS")
public class CallDetails {
@Id
@Column(name="CALL_ID")
private Long callId;
@Column(name="CALLED_BY")
private Long calledBy;
@Column(name="CALLED_ON")
@Temporal(TemporalType.DATE)
private Date calledOn;
@Column(name="CALLED_TO")
private Long calledTo;
public Long getCalledTo() {
	return calledTo;
}
public void setCalledTo(Long calledTo) {
	this.calledTo = calledTo;
}
@Column(name="DURATION_IN_SECONDS")
private Long durationInSeconds;
public Long getCallId() {
	return callId;
}
public void setCallId(Long callId) {
	this.callId = callId;
}
public Long getCalledBy() {
	return calledBy;
}
public void setCalledBy(Long calledBy) {
	this.calledBy = calledBy;
}
public Date getCalledOn() {
	return calledOn;
}
public void setCalledOn(Date calledOn) {
	this.calledOn = calledOn;
}
public Long getDurationInSeconds() {
	return durationInSeconds;
}
public void setDurationInSeconds(Long durationInSeconds) {
	this.durationInSeconds = durationInSeconds;
}

}
