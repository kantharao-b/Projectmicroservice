package com.plan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Plan {
@Id
@Column(length=20)
private String planId;
@Column(length=25)
private String planName;
@Column(length=30)
private Integer validity;
@Column(length=20)
private String description;
public String getPlanId() {
	return planId;
}
public void setPlanId(String planId) {
	this.planId = planId;
}
public String getPlanName() {
	return planName;
}
public void setPlanName(String planName) {
	this.planName = planName;
}
public Integer getValidity() {
	return validity;
}
public void setValidity(Integer validity) {
	this.validity = validity;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}

}
