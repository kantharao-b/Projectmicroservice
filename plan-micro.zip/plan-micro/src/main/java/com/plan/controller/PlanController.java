package com.plan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.plan.DTO.PlanDTO;
import com.plan.service.PlanService;

@RestController
public class PlanController {
@Autowired
private PlanService service;
@GetMapping("/plans")
public List<PlanDTO> findAllPlans(){
	return service.findAllPlans();
	}
@GetMapping("/{planId}")
public PlanDTO getPlanByPlanID(@PathVariable String planId) {
	return service.findByPlanId(planId);
}
}
