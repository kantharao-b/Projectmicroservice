package com.plan.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.plan.DTO.PlanDTO;
import com.plan.entity.Plan;
import com.plan.repository.PlanRepository;
@Service
public class PlanServiceImpl implements PlanService {
@Autowired
private PlanRepository repo;
	@Override
	public List<PlanDTO> findAllPlans() {
		List<Plan> list = repo.findAll();
		List<PlanDTO> listPlan=new ArrayList<PlanDTO>();
		for(Plan plan:list) {
			PlanDTO dto=new PlanDTO();
			BeanUtils.copyProperties(plan, dto);
			listPlan.add(dto);
		}
		return listPlan;
	}

	@Override
	public PlanDTO findByPlanId(String PlanId) {
		Optional<Plan> id = repo.findById(PlanId);
		Plan plan = id.get();
		PlanDTO dto=new PlanDTO();
		BeanUtils.copyProperties(plan, dto);
		return dto;
	}

}
