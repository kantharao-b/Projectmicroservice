package com.plan.service;

import java.util.List;

import com.plan.DTO.PlanDTO;

public interface PlanService {
List<PlanDTO> findAllPlans();
PlanDTO findByPlanId(String PlanId);
}
