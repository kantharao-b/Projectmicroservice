package com.plan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlanMicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlanMicroApplication.class, args);
	}

}
